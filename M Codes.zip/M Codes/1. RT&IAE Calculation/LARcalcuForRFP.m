clc
t0 = [0;2;4;6;8;10;12;20;22;24;48;72];
t00 = 0:1:72;
t1 = 0:1:20;
t2 = 20:1:72;
c1 = [0.0638;0.226;0.193;3.294;4.433;7.333;6.932;7.442;7.296;7.515;7.187;7.114];
c2 = [0.0638;0.195;0.179;3.075;4.320;5.764;6.676;6.822;5.837;6.640;6.421;6.859];
c3 = [0.0638;0.179;0.166;2.886;3.718;5.637;6.293;6.239;5.728;5.837;6.111;6.093]; 
cinitial = [0.0638 0.0638 0.0638 0 0 0 0 0 0 0 0 0];

options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
[t,c]=ode45(@LARcontrol,t00,cinitial,options);
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
BFP01 = c(:,1);
GFP02 = c(:,2);
RFP03 = c(:,3);
PartBFP = BFP01(21:end);
PartGFP = GFP02(21:end);
PartRFP = RFP03(21:end);
%GFP strain change
[t,c]=ode45(@LARcontrol,t1,cinitial,options);
cinitial2 = c(end,:);
cinitial2(3) = cinitial2(3).*(1-0.1);
cinitial3 = c(end,:);
cinitial3(3) = cinitial3(3).*(1+0.1);
cinitial4 = c(end,:);
cinitial4(3) = cinitial4(3).*(1-0.5);
cinitial5 = c(end,:);
cinitial5(3) = cinitial5(3).*(1+0.5);
[t,c2]=ode45(@LARcontrol,t2,cinitial2,options);%-10%
BFP12 = [c(:,1);c2(:,1)];
GFP22 = [c(:,2);c2(:,2)];
RFP32 = [c(:,3);c2(:,3)];
PerBFP12 = c2(end,1)/(c2(end,1)+c2(end,2)+c2(end,3));
PerGFP22 = c2(end,2)/(c2(end,1)+c2(end,2)+c2(end,3));
PerRFP32 = c2(end,3)/(c2(end,1)+c2(end,2)+c2(end,3));
[t,c3]=ode45(@LARcontrol,t2,cinitial3,options);%+10%
BFP13 = [c(:,1);c3(:,1)];
GFP23 = [c(:,2);c3(:,2)];
RFP33 = [c(:,3);c3(:,3)];
PerBFP13 = c3(end,1)/(c3(end,1)+c3(end,2)+c3(end,3));
PerGFP23 = c3(end,2)/(c3(end,1)+c3(end,2)+c3(end,3));
PerRFP33 = c3(end,3)/(c3(end,1)+c3(end,2)+c3(end,3));
[t,c4]=ode45(@LARcontrol,t2,cinitial4,options);%-50%
BFP14 = [c(:,1);c4(:,1)];
GFP24 = [c(:,2);c4(:,2)];
RFP34 = [c(:,3);c4(:,3)];
PerBFP14 = c4(end,1)/(c4(end,1)+c4(end,2)+c4(end,3));
PerGFP24 = c4(end,2)/(c4(end,1)+c4(end,2)+c4(end,3));
PerRFP34 = c4(end,3)/(c4(end,1)+c4(end,2)+c4(end,3));
[t,c5]=ode45(@LARcontrol,t2,cinitial5,options);%+50%
BFP15 = [c(:,1);c5(:,1)];
GFP25 = [c(:,2);c5(:,2)];
RFP35 = [c(:,3);c5(:,3)];
PerBFP15 = c5(end,1)/(c5(end,1)+c5(end,2)+c5(end,3));
PerGFP25 = c5(end,2)/(c5(end,1)+c5(end,2)+c5(end,3));
PerRFP35 = c5(end,3)/(c5(end,1)+c5(end,2)+c5(end,3));

FTBFP12=find(abs(diff(c2(:,1)))<=0.001,1,'first');
FTBFP13=find(abs(diff(c3(:,1)))<=0.001,1,'first');
FTBFP14=find(abs(diff(c4(:,1)))<=0.001,1,'first');
FTBFP15=find(abs(diff(c5(:,1)))<=0.001,1,'first');

FTGFP22=find(abs(diff(c2(:,2)))<=0.001,1,'first');
FTGFP23=find(abs(diff(c3(:,2)))<=0.001,1,'first');
FTGFP24=find(abs(diff(c4(:,2)))<=0.001,1,'first');
FTGFP25=find(abs(diff(c5(:,2)))<=0.001,1,'first');

FTRFP32=find(abs(diff(c2(:,3)))<=0.001,1,'first');
FTRFP33=find(abs(diff(c3(:,3)))<=0.001,1,'first');
FTRFP34=find(abs(diff(c4(:,3)))<=0.001,1,'first');
FTRFP35=find(abs(diff(c5(:,3)))<=0.001,1,'first');

IAEBFP12 = abs(sum(c2(:,1)-PartBFP));
IAEBFP13 = abs(sum(c3(:,1)-PartBFP));
IAEBFP14 = abs(sum(c4(:,1)-PartBFP));
IAEBFP15 = abs(sum(c5(:,1)-PartBFP));

IAEGFP22 = abs(sum(c2(:,2)-PartGFP));
IAEGFP23 = abs(sum(c3(:,2)-PartGFP));
IAEGFP24 = abs(sum(c4(:,2)-PartGFP));
IAEGFP25 = abs(sum(c5(:,2)-PartGFP));

IAERFP32 = abs(sum(c2(:,3)-PartRFP));
IAERFP33 = abs(sum(c3(:,3)-PartRFP));
IAERFP34 = abs(sum(c4(:,3)-PartRFP));
IAERFP35 = abs(sum(c5(:,3)-PartRFP));

figure
hold on
plot([t1 t2],BFP12,'-b','linewidth',1)
plot([t1 t2],GFP22,'--g','linewidth',1)
plot([t1 t2],RFP32,':r','linewidth',1)
plot([t1 t2],BFP13,'-b','linewidth',1)
plot([t1 t2],GFP23,'--g','linewidth',1)
plot([t1 t2],RFP33,':r','linewidth',1)
plot(t00,BFP01,'-b','linewidth',1)
plot(t00,GFP02,'-g','linewidth',1)
plot(t00,RFP03,'-r','linewidth',1)
grid on;
box on;
title ('BFP strain +/-10%')
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
set(gca,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'BFP strain','GFP strain','RFP strain'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');