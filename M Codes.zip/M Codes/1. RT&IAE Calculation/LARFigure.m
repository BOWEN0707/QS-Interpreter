clc
cA = [0.0638;0.226;0.193;3.294;4.433;7.333;6.932;7.442;7.296;7.515;7.187;7.114];
cB = [0.0638;0.195;0.179;3.075;4.320;5.764;6.676;6.822;5.837;6.640;6.421;6.859];
cC = [0.0638;0.179;0.166;2.886;3.718;5.637;6.293;6.239;5.728;5.837;6.111;6.093]; 
t0 = [0;2;4;6;8;10;12;20;22;24;48;72];
t1 = 0:1:72;
cinitial = [0.0638 0.0638 0.0638 0 0 0 0 0 0 0 0 0];
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
[t,c]=ode45(@LARcontrol,t1,cinitial,options);
BFPstrain1 = c(:,1);
GFPstrain2 = c(:,2);
RFPstrain3 = c(:,3);

figure
hold on
plot(t0,cA,'b*')
plot(t0,cB,'g*')
plot(t0,cC,'r*')
plot(t1,BFPstrain1,'-b','linewidth',1)
plot(t1,GFPstrain2,'--g','linewidth',1)
plot(t1,RFPstrain3,':r','linewidth',1)
grid on;
box on;
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'Strain 1 (BFP)','Strain 2 (GFP)','Strain 3 (RFP)'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');

figure
hold on
[t,c]=ode45(@LARcontrol,t1,cinitial,options);
plot(t1,c(:,4),'-b','linewidth',1)
plot(t1,c(:,7),'--r','linewidth',1)
plot(t1,c(:,10),':k','linewidth',1)
grid on;
box on;
xlabel('Time(Hours)')
ylabel('Concentration (nM)')
set(gca,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'Rpa AHL','Lux AHL','Las AHL'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');