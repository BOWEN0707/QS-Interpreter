clc
tic
t0 =0:1:72;
t1 = 0:1:20;
t2 = 20:1:72;
cinitial = [0.0638 0.0638 0.0638 0 0 0 0 0 0 0 0 0];
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
r = [0.01:0.01:0.3];
D = [0.01:0.01:0.3];
% r = [0.01,0.02,0.05,0.1,0.2,0.3];
% D = [0.01,0.02,0.05,0.1,0.2,0.3];
B = ones(length(r),length(D));
G = ones(length(r),length(D));
R = ones(length(r),length(D));
RTA = ones(length(r),length(D));
RTB = ones(length(r),length(D));
RTE = ones(length(r),length(D));
for i=1:length(r)
    for j=1:length(D)
       [t,c]=ode45(@LARcontrolforOPT,t0,cinitial,[],r(1,i),D(1,j));           
B(i,j)=c(end,1);
G(i,j)=c(end,2);
R(i,j)=c(end,3);
cinitial1 = c(end,:);
cinitial1(1) = cinitial1(1).*(1-0.5);
[t,c1]=ode45(@LARcontrolforOPT,t2,cinitial1,[],r(1,i),D(1,j));%-50%
BFP11 = [c(:,1);c1(:,1)];
GFP21 = [c(:,2);c1(:,2)];
RFP31 = [c(:,3);c1(:,3)];
FTA=find(diff(c1(:,1))<=0.001,1,'first');
if ~isempty(FTA)
    RTA(i,j) = t0(FTA(1));
else
    RTA(i,j) = 52;
end
FTB=find(diff(c1(:,2))<=0.001,1,'first');
if ~isempty(FTB)
    RTB(i,j) = t0(FTB(1));
else
    RTB(i,j) = 52;
end
FTE=find(diff(c1(:,3))<=0.001,1,'first');
if ~isempty(FTE)
    RTE(i,j) = t0(FTE(1));
else
    RTE(i,j) = 52;
end
   end
end
toc
figure
hold on
h=bar3(RTA,1);
for p=1:numel(h)
    cdata=get(h(p),'zdata');
    set(h(p),'cdata',cdata,'facecolor','interp')
end
xlabel('Dilution rate (D)','fontsize',20,'fontname','Times');
ylabel('Promoted growth rate (\gamma)','fontsize',20,'fontname','Times');
zlabel('Response time (RT) (h)','fontsize',20,'fontname','Times');
colormap parula
colorbar('location','EastOutside')%ɫ��
xlim([0 31])
ylim([0 31])

figure
hold on
h=bar3(RTB,1);
for p=1:numel(h)
    cdata=get(h(p),'zdata');
    set(h(p),'cdata',cdata,'facecolor','interp')
end
xlabel('Dilution rate (D)','fontsize',20,'fontname','Times');
ylabel('Promoted growth rate (\gamma)','fontsize',20,'fontname','Times');
zlabel('Response time (RT) (h)','fontsize',20,'fontname','Times');
colormap parula
colorbar('location','EastOutside')%ɫ��
xlim([0 31])
ylim([0 31])

figure
hold on
h=bar3(RTE,1);
for p=1:numel(h)
    cdata=get(h(p),'zdata');
    set(h(p),'cdata',cdata,'facecolor','interp')
end
xlabel('Dilution rate (D)','fontsize',20,'fontname','Times');
ylabel('Promoted growth rate (\gamma)','fontsize',20,'fontname','Times');
zlabel('Response time (RT) (h)','fontsize',20,'fontname','Times');
colormap parula
colorbar('location','EastOutside')%ɫ��
xlim([0 31])
ylim([0 31])