clc
tic
t0 =0:1:72;
cinitial = [0.0638 0.0638 0.0638 0 0 0 0 0 0 0 0 0];
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
r = [0.01:0.01:0.3];
D = [0.01:0.01:0.3];
% r = [0.01,0.02,0.05,0.1,0.2,0.3];
% D = [0.01,0.02,0.05,0.1,0.2,0.3];
B = ones(length(r),length(D));
G = ones(length(r),length(D));
R = ones(length(r),length(D));
MFTA = ones(length(r),length(D));
MFTB = ones(length(r),length(D));
MFTE = ones(length(r),length(D));
for i=1:length(r)
    for j=1:length(D)
       [t,c]=ode45(@LARcontrolforOPT,t0,cinitial,[],r(1,i),D(1,j));           
B(i,j)=c(end,1);
G(i,j)=c(end,2);
R(i,j)=c(end,3);
FTA=find(diff(c(:,1))<=0.001,1,'first');
if ~isempty(FTA)
    MFTA(i,j) = t0(FTA(1));
else
    MFTA(i,j) = 72;
end
FTB=find(diff(c(:,2))<=0.001,1,'first');
if ~isempty(FTB)
    MFTB(i,j) = t0(FTB(1));
else
    MFTB(i,j) = 72;
end
FTE=find(diff(c(:,3))<=0.001,1,'first');
if ~isempty(FTE)
    MFTE(i,j) = t0(FTE(1));
else
    MFTE(i,j) = 72;
end
        end
end
toc
figure
hold on
h=bar3(MFTA,1);
for p=1:numel(h)
    cdata=get(h(p),'zdata');
    set(h(p),'cdata',cdata,'facecolor','interp')
end
xlabel('Dilution rate (D)','fontsize',20,'fontname','Times');
ylabel('Promoted growth rate (\gamma)','fontsize',20,'fontname','Times');
zlabel('Minimum fermentation time (MT) (h)','fontsize',14,'fontname','Times');
colormap parula
colorbar('location','EastOutside')%ɫ��
xlim([0 31])
ylim([0 31])

figure
hold on
h=bar3(MFTB,1);
for p=1:numel(h)
    cdata=get(h(p),'zdata');
    set(h(p),'cdata',cdata,'facecolor','interp')
end
xlabel('Dilution rate (D)','fontsize',20,'fontname','Times');
ylabel('Promoted growth rate (\gamma)','fontsize',20,'fontname','Times');
zlabel('Minimum fermentation time (MT) (h)','fontsize',14,'fontname','Times');
colormap parula
colorbar('location','EastOutside')%ɫ��
xlim([0 31])
ylim([0 31])

figure
hold on
h=bar3(MFTE,1);
for p=1:numel(h)
    cdata=get(h(p),'zdata');
    set(h(p),'cdata',cdata,'facecolor','interp')
end
xlabel('Dilution rate (D)','fontsize',20,'fontname','Times');
ylabel('Promoted growth rate (\gamma)','fontsize',20,'fontname','Times');
zlabel('Minimum fermentation time (MT) (h)','fontsize',14,'fontname','Times');
colormap parula
colorbar('location','EastOutside')%ɫ��
xlim([0 31])
ylim([0 31])