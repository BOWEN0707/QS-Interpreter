clc
tic
t0 =0:1:72;
BFP0 = [0.0638;0.226;0.193;3.294;4.433;7.333;6.932;7.442;7.296;7.515;7.187;7.114];
GFP0 = [0.0638;0.195;0.179;3.075;4.320;5.764;6.676;6.822;5.837;6.640;6.421;6.859];
RFP0 = [0.0638;0.179;0.166;2.886;3.718;5.637;6.293;6.239;5.728;5.837;6.111;6.093]; 

BFP1 = [0.064;0.231;0.897;2.607;4.911;6.231;6.786;6.675;6.801;6.878;7.054;7.345];
GFP1 = [0.064;0.223;0.831;2.382;4.381;5.784;5.956;6.118;6.095;6.359;6.139;6.038];
RFP1 = [0.064;0.210;0.867;2.256;4.012;4.991;5.351;5.218;5.241;5.417;5.101;4.951];

BFP2 = [0.0656;0.229;0.655;1.919;4.065;5.589;6.130;6.209;6.450;6.470;6.472;6.841];
GFP2 = [0.0656;0.196;0.638;1.915;3.744;4.852;5.391;5.967;5.618;5.441;5.705;5.621];
RFP2 = [0.0656;0.177;0.640;1.563;3.559;4.249;5.128;4.287;4.933;4.750;4.683;4.100];

t1 = [0;2;4;6;8;10;12;20;22;24;48;72];
cinitial = [0.0638 0.0638 0.0638 0 0 0 0 0 0 0 0 0];
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
D = [0.01,0.05,0.076,0.1,0.134,0.3];
B = ones(length(D));
RTA = ones(length(D));
figure; 
hold on
plot(t1,BFP0,'*b','linewidth',1)
plot(t1,BFP1,'ob','linewidth',1)
plot(t1,BFP2,'sb','linewidth',1)
for i=1:length(D)   
[t,c]=ode45(@LARcontrolD,t0,cinitial,[],D(1,i));
plot(t0,c(:,1),'-b','linewidth',1)
annotation('textbox',...
    'String',{['D=',num2str(D(i))]},...
    'fontname','times new roman',...
    'fontsize',16,'fontname','Times',...
    'LineStyle','none',...
    'FitBoxToText','off');
end
grid on;
box on;
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
% ylim([0 5])
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'Strain A (BFP)'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');

figure; 
hold on
plot(t1,GFP0,'*g','linewidth',1)
plot(t1,GFP1,'og','linewidth',1)
plot(t1,GFP2,'sg','linewidth',1)
for i=1:length(D)   
[t,c]=ode45(@LARcontrolD,t0,cinitial,[],D(1,i));
plot(t0,c(:,2),'-g','linewidth',1)
annotation('textbox',...
    'String',{['D=',num2str(D(i))]},...
    'fontname','times new roman',...
    'fontsize',16,'fontname','Times',...
    'LineStyle','none',...
    'FitBoxToText','off');
end
grid on;
box on;
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
% ylim([0 2])
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'Strain B (GFP)'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');

figure; 
hold on
plot(t1,RFP0,'*r','linewidth',1)
plot(t1,RFP1,'or','linewidth',1)
plot(t1,RFP2,'sr','linewidth',1)
for i=1:length(D)   
[t,c]=ode45(@LARcontrolD,t0,cinitial,[],D(1,i));
plot(t0,c(:,3),'-r','linewidth',1)
annotation('textbox',...
    'String',{['D=',num2str(D(i))]},...
    'fontname','times new roman',...
    'fontsize',16,'fontname','Times',...
    'LineStyle','none',...
    'FitBoxToText','off');
end
grid on;
box on;
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
% ylim([0 2])
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'Strain E (RFP)'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');
toc