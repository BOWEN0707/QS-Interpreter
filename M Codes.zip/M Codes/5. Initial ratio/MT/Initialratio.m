clear all
clc
tic
t0 = 0:1:200;
m=0.2;%initial Total cell density
n1 = [1/3;1/4;1/7;1/12;1/5;1/6;1/11;1/16];%BFP strain 
n2 = [1/3;1/4;1/7;1/12;2/5;2/6;5/11;5/16];%GFP strain
n3 = [1/3;2/4;5/7;10/12;2/5;3/6;5/11;10/16];%RFP strain
C1=ones(1,length(n1));
C2=ones(1,length(n1));
C3=ones(1,length(n1));
PPBFP = ones(1,length(n1));
PPGFP = ones(1,length(n1));
PPRFP = ones(1,length(n1));
TBFP = ones(1,length(n1));
TGFP = ones(1,length(n1));
TRFP = ones(1,length(n1));
for i=1:length(n1)
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
[t,c]=ode45(@LARcontrol,t0,[m*n1(i) m*n2(i) m*n3(i) 0 0 0 0 0 0 0 0 0],options);
C1(i)=c(end,1);
C2(i)=c(end,2);
C3(i)=c(end,3);
TBFP(i)=find(abs(diff(c(:,1)))<=0.0001,1,'first');
TGFP(i)=find(abs(diff(c(:,2)))<=0.0001,1,'first');
TRFP(i)=find(abs(diff(c(:,3)))<=0.0001,1,'first');
PPBFP(i)=C1(i)./(C1(i)+C2(i)+C3(i));
PPGFP(i)=C2(i)./(C1(i)+C2(i)+C3(i));
PPRFP(i)=C3(i)./(C1(i)+C2(i)+C3(i));
end
toc

figure
hold on
h=bar3(PPBFP:PPGFP:PPRFP,0.4);
for p=1:numel(h)
    cdata=get(h(p),'zdata');
    set(h(p),'cdata',cdata,'facecolor','interp')
end
xlabel('GLU strain %','fontsize',20,'fontname','Times');
ylabel('Total C0','fontsize',20,'fontname','Times');
zlabel('Minimum degradation time(h)','fontsize',16,'fontname','Times');
xlim([0 11])
ylim([0 11])