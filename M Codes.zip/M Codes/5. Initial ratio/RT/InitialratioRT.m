clear all
clc
tic
t0 = 0:1:250;
t1 = 0:1:20;
t2 = 20:1:250;
m=0.2;%initial Total cell density
n1 = [1/3;1/4;1/7;1/12;1/5;1/6;1/11;1/16];%BFP strain 
n2 = [1/3;1/4;1/7;1/12;2/5;2/6;5/11;5/16];%GFP strain
n3 = [1/3;2/4;5/7;10/12;2/5;3/6;5/11;10/16];%RFP strain
C1=ones(1,length(n1));
C2=ones(1,length(n1));
C3=ones(1,length(n1));
PPBFP = ones(1,length(n1));
PPGFP = ones(1,length(n1));
PPRFP = ones(1,length(n1));
T1BFP = ones(1,length(n1));
T1GFP = ones(1,length(n1));
T1RFP = ones(1,length(n1));
T2BFP = ones(1,length(n1));
T2GFP = ones(1,length(n1));
T2RFP = ones(1,length(n1));
T3BFP = ones(1,length(n1));
T3GFP = ones(1,length(n1));
T3RFP = ones(1,length(n1));
for i=1:length(n1)
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
[t,c]=ode45(@LARcontrol,t1,[m*n1(i) m*n2(i) m*n3(i) 0 0 0 0 0 0 0 0 0],options);
cinitial4 = c(end,:);
cinitial4(1) = cinitial4(1).*(1-0.5);
[t,c4]=ode45(@LARcontrol,t2,cinitial4,options);%-50%
BFP14 = [c(:,1);c4(:,1)];
GFP24 = [c(:,2);c4(:,2)];
RFP34 = [c(:,3);c4(:,3)];
T1BFP(i)=find(abs(diff(c4(:,1)))<=0.001,1,'first');
T1GFP(i)=find(abs(diff(c4(:,2)))<=0.001,1,'first');
T1RFP(i)=find(abs(diff(c4(:,3)))<=0.001,1,'first');
end

for i=1:length(n1)
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
[t,c]=ode45(@LARcontrol,t1,[m*n1(i) m*n2(i) m*n3(i) 0 0 0 0 0 0 0 0 0],options);
cinitial5 = c(end,:);
cinitial5(2) = cinitial5(2).*(1-0.5);
[t,c5]=ode45(@LARcontrol,t2,cinitial5,options);%-50%
BFP15 = [c(:,1);c5(:,1)];
GFP25 = [c(:,2);c5(:,2)];
RFP35 = [c(:,3);c5(:,3)];
T2BFP(i)=find(abs(diff(c5(:,1)))<=0.001,1,'first');
T2GFP(i)=find(abs(diff(c5(:,2)))<=0.001,1,'first');
T2RFP(i)=find(abs(diff(c5(:,3)))<=0.001,1,'first');
end

for i=1:length(n1)
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
[t,c]=ode45(@LARcontrol,t1,[m*n1(i) m*n2(i) m*n3(i) 0 0 0 0 0 0 0 0 0],options);
cinitial6 = c(end,:);
cinitial6(3) = cinitial6(3).*(1-0.5);
[t,c6]=ode45(@LARcontrol,t2,cinitial6,options);%-50%
BFP16 = [c(:,1);c6(:,1)];
GFP26 = [c(:,2);c6(:,2)];
RFP36 = [c(:,3);c6(:,3)];
T3BFP(i)=find(abs(diff(c6(:,1)))<=0.001,1,'first');
T3GFP(i)=find(abs(diff(c6(:,2)))<=0.001,1,'first');
T3RFP(i)=find(abs(diff(c6(:,3)))<=0.001,1,'first');
end
toc