%M file for Figure S7
clc
tic
t00 =0:1:72;
t1 = 0:1:20;
t2 = 20:1:72;
cinitial = [0.0638 0.0638 0.0638 0 0 0 0 0 0 0 0 0];
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
% r1 = [-1,0,1];
% r2 = [-1,0,1];
% k =  [-1,0,1];
r1 = [-0.01,0,0.01];
r2 = [-0.01,0,0.01];
k =  [-0.01,0,0.01];

figure
hold on
count = 1;
for i=1:length(r1)
    for j=1:length(r2)
        for m=1:length(k) 
[t,c]=ode45(@LARcontrolforOPT,t00,cinitial,[],r1(1,i),r2(1,j),k(1,m));
BFP01 = c(:,1);
GFP02 = c(:,2);
RFP03 = c(:,3);
[t,c]=ode45(@LARcontrolforOPT,t1,cinitial,[],r1(1,i),r2(1,j),k(1,m));
cinitial2 = c(end,:);
cinitial2(1) = cinitial2(1).*(1-0.5);
[t,c2]=ode45(@LARcontrolforOPT,t2,cinitial2,[],r1(1,i),r2(1,j),k(1,m));
BFP1 = [c(:,1);c2(:,1)];
GFP2 = [c(:,2);c2(:,2)];
RFP3 = [c(:,3);c2(:,3)];
subplot(9,3,count)
hold on
count=count+1;
plot([t1 t2],BFP1,'-b','linewidth',2)
plot([t1 t2],GFP2,'-g','linewidth',2)
plot([t1 t2],RFP3,'-r','linewidth',2)
plot(t00,BFP01,':b','linewidth',1)
plot(t00,GFP02,'--g','linewidth',1)
plot(t00,RFP03,'.r','linewidth',1)
grid on;
box on;
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',16,'fontname','Times');
% annotation('textbox',...
%     'String',{['r_A=',num2str(r1(i)),'; ','r_B=',num2str(r2(j)),'; ', 'r_E=',num2str(k(m))]},...
%     'fontname','times new roman',...
%     'fontsize',12,'fontname','Times',...
%     'LineStyle','none',...
%     'FitBoxToText','off');

        end
    end
end
toc