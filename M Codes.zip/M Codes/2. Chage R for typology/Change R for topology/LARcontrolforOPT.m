function [dc] = LARcontrolforOPT(t,c,r1,r2,k)
g1 = 0.77;% growth rate of the BFP (rpa) strain
g2 = 0.76;% growth rate of the GFP (rpa) strain
g3 = 0.74;% growth rate of the RFP (rpa) strain
Cm = 20.0;
%%
%r1 = 0.02;
%r2 = 0.02;
%k = 0.02;
D = 0.01;
%QS1, LUX, L
aA1 = 0.4;% 0.4 is the basal production rate of the QS agent,IPTG�� from Frederick K. Balagadd�� et al 2008
aAstar1 = 8;% 8 The production rate of lux AHL can be increased to a maximum production rate of ��A+ ��A*
Ac1 = 1;% 1
rA1 = 1;% 1��A is the degradation of AHL
%QS2,LAS, A
aA2 = 0.5;                           %0.4, 0.5,  0.72, 0.22,
aAstar2 = 25;                        %8,   25,   7,    1.37;
Ac2 = 0.26;                          %1,   0.26, 0.1,  7
rA2 = 0.8;                             %1,   0.8,  1.2,  0.9;
%QS3,RPA, R
aA3 = 0.72;                          %0.4, 0.5,  0.72, 0.22,
aAstar3 = 7;                         %8,   25,   7,    1.37;
Ac3 = 0.1;                           %1,   0.26, 0.1,  7
rA3 = 1.2;                           %1,   0.8,  1.2,  0.9;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rou = 0.5;% ��M-3 min-1 (LuxR/AHL dimerization)
vR = 1;
rR = 0.1;
rAR = 0.0231;%min-1 (protein decay)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dc=zeros(12,1);
dc(1)=(g1*c(1)*(1-(c(1)+c(2)+c(3))/Cm)+(c(4)^2/(Ac3^2+c(4)^2))*r1*c(1))-D*c(1);% strain 1 (BFP),produce A1
dc(2)=(g2*c(2)*(1-(c(1)+c(2)+c(3))/Cm)+(c(7)^2/(Ac1^2+c(7)^2))*r2*c(2))-D*c(2);%strain 2 (GFP),produce A2
dc(3)=(g3*c(3)*(1-(c(1)+c(2)+c(3))/Cm)+(c(10)^2/(Ac2^2+c(10)^2))*k*c(3))-D*c(3);% strain 3 (RFP),produce A3
dc(4)=(aA3+aAstar3*(c(4)^2/(Ac3^2+c(4)^2)))*c(3)-rA3*c(4)-2*rou*c(4)^2*c(5)^2+2*rAR*c(6);%A3, RpaI
dc(5)=vR*c(1)-rR*c(5)-2*rou*c(4)^2*c(5)^2+2*rAR*c(6);%R1, RpaR
dc(6)=rou*c(4)^2*c(5)^2-rAR*c(6);%A3R1 Complex
dc(7)=(aA1+aAstar1*(c(7)^2/(Ac1^2+c(7)^2)))*c(1)-rA1*c(7)-2*rou*c(7)^2*c(8)^2+2*rAR*c(9);%A1, LuxI
dc(8)=vR*c(2)-rR*c(8)-2*rou*c(7)^2*c(8)^2+2*rAR*c(9);%R2, LuxR
dc(9)=rou*c(7)^2*c(8)^2-rAR*c(9);%A1R2 Complex
dc(10)=(aA2+aAstar2*(c(10)^2/(Ac2^2+c(10)^2)))*c(2)-rA2*c(10)-2*rou*c(10)^2*c(11)^2+2*rAR*c(12);%A2, LasI
dc(11)=vR*c(3)-rR*c(11)-2*rou*c(10)^2*c(11)^2+2*rAR*c(12);%R3, LasR
dc(12)=rou*c(10)^2*c(11)^2-rAR*c(12);%A2R3 Complex
end
