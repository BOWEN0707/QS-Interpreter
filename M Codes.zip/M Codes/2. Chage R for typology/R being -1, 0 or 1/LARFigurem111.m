clc
t0 = [0;2;4;6;8;10;12;20;22;24;48;72];
t00 = 0:1:72;
t1 = 0:1:20;
t2 = 20:1:72;
c1 = [0.0638;0.226;0.193;3.294;4.433;7.333;6.932;7.442;7.296;7.515;7.187;7.114];
c2 = [0.0638;0.195;0.179;3.075;4.320;5.764;6.676;6.822;5.837;6.640;6.421;6.859];
c3 = [0.0638;0.179;0.166;2.886;3.718;5.637;6.293;6.239;5.728;5.837;6.111;6.093]; 
cinitial = [0.0638 0.0638 0.0638 0 0 0 0 0 0 0 0 0];

options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
[t,c]=ode45(@LARcontrolm111,t00,cinitial,options);
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
BFP01 = c(:,1);
GFP02 = c(:,2);
RFP03 = c(:,3);

[t,c]=ode45(@LARcontrolm111,t1,cinitial,options);
cinitial2 = c(end,:);
cinitial2(1) = cinitial2(1).*(1-0.5);
[t,c2]=ode45(@LARcontrolm111,t2,cinitial2,options);
BFP1 = [c(:,1);c2(:,1)];
GFP2 = [c(:,2);c2(:,2)];
RFP3 = [c(:,3);c2(:,3)];

subplot(1,3,1)
hold on
plot([t1 t2],BFP1,'-b','linewidth',2)
plot([t1 t2],GFP2,'-g','linewidth',2)
plot([t1 t2],RFP3,'-r','linewidth',2)
plot(t00,BFP01,':b','linewidth',1)
plot(t00,GFP02,'--g','linewidth',1)
plot(t00,RFP03,'.r','linewidth',1)
grid on;
box on;
title ('BFP strain -50%')
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
% ylim([0 10])
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'BFP strain','GFP strain','RFP strain'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');

[t,c]=ode45(@LARcontrolm111,t1,cinitial,options);
cinitial2 = c(end,:);
cinitial2(2) = cinitial2(2).*(1-0.5);
[t,c2]=ode45(@LARcontrolm111,t2,cinitial2,options);
BFP1 = [c(:,1);c2(:,1)];
GFP2 = [c(:,2);c2(:,2)];
RFP3 = [c(:,3);c2(:,3)];

subplot(1,3,2)
hold on
plot([t1 t2],BFP1,'-b','linewidth',2)
plot([t1 t2],GFP2,'-g','linewidth',2)
plot([t1 t2],RFP3,'-r','linewidth',2)
plot(t00,BFP01,':b','linewidth',1)
plot(t00,GFP02,'--g','linewidth',1)
plot(t00,RFP03,'.r','linewidth',1)
grid on;
box on;
title ('GFP strain -50%')
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
% ylim([0 12])
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'BFP strain','GFP strain','RFP strain'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');

[t,c]=ode45(@LARcontrolm111,t1,cinitial,options);
cinitial2 = c(end,:);
cinitial2(3) = cinitial2(3).*(1-0.5);
[t,c2]=ode45(@LARcontrolm111,t2,cinitial2,options);
BFP1 = [c(:,1);c2(:,1)];
GFP2 = [c(:,2);c2(:,2)];
RFP3 = [c(:,3);c2(:,3)];

subplot(1,3,3)
hold on
plot([t1 t2],BFP1,'-b','linewidth',2)
plot([t1 t2],GFP2,'-g','linewidth',2)
plot([t1 t2],RFP3,'-r','linewidth',2)
plot(t00,BFP01,':b','linewidth',1)
plot(t00,GFP02,'--g','linewidth',1)
plot(t00,RFP03,'.r','linewidth',1)
grid on;
box on;
title ('RFP strain -50%')
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
% ylim([0 12])
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'BFP strain','GFP strain','RFP strain'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');