function [dc] = LARcontrol000(t,c)
g1 = 0.77;% growth rate of the BFP (rpa) strain
g2 = 0.76;% growth rate of the GFP (rpa) strain
g3 = 0.74;% growth rate of the RFP (rpa) strain
Cm = 20.0;
%%
D = 0.01;
%QS1, LUX, L
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dc=zeros(3,1);
dc(1)=(g1*c(1)*(1-(c(1)+c(2)+c(3))/Cm))-D*c(1);% strain 1 (BFP)
dc(2)=(g2*c(2)*(1-(c(1)+c(2)+c(3))/Cm))-D*c(2);% strain 2 (GFP)
dc(3)=(g3*c(3)*(1-(c(1)+c(2)+c(3))/Cm))-D*c(3);% strain 3 (RFP)
end
