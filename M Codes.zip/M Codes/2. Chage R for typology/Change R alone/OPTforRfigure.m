%M file for Figure 5c Change R alone
clc
tic
t00 =0:1:72;
t1 = 0:1:20;
t2 = 20:1:72;
cinitial = [0.0638 0.0638 0.0638 0 0 0 0 0 0 0 0 0];
options = odeset('NonNegative',[1 2 3 4 5 6 7 8 9 10 11 12]);
r = [0.01,0.05,0.1,0.5,1];
%D = 0.001:0.01:1;
B = ones(length(r));
RTA = ones(length(r));
Ac3 =0.1;
g1 =0.77;
Cm = 20;

figure
hold on
for i=1:length(r)   
[t,c]=ode45(@LARcontrolforR,t00,cinitial,[],r(1,i));
BFP01 = c(:,1);
[t,c]=ode45(@LARcontrolforR,t1,cinitial,[],r(1,i));
cinitial2 = c(end,:);
cinitial2(1) = cinitial2(1).*(1-0.5);
[t,c2]=ode45(@LARcontrolforR,t2,cinitial2,[],r(1,i));
BFP1 = [c(:,1);c2(:,1)];
plot([t1 t2],BFP1,'-b','linewidth',4)
plot(t00,BFP01,'--b','linewidth',4)
grid on;
box on;
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',16,'fontname','Times');
annotation('textbox',...
    'String',{['r=',num2str(r(i))]},...
    'fontname','times new roman',...
    'fontsize',16,'fontname','Times',...
    'LineStyle','none',...
    'FitBoxToText','off');
B(i)=c(end,1);
FTA=find(diff(c(:,1))>=0.00001,1,'last');
if ~isempty(FTA)
    RTA(i) = t00(FTA(1));
else
    RTA(i) = 72;
end
end
grid on;
box on;
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
% ylim([0 5])
set(gca,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'Strain A (BFP)'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');

figure
hold on
for i=1:length(r)   
[t,c]=ode45(@LARcontrolforR,t00,cinitial,[],r(1,i));
GFP01 = c(:,2);
[t,c]=ode45(@LARcontrolforR,t1,cinitial,[],r(1,i));
cinitial2 = c(end,:);
cinitial2(2) = cinitial2(2).*(1-0.5);
[t,c2]=ode45(@LARcontrolforR,t2,cinitial2,[],r(1,i));
GFP1 = [c(:,2);c2(:,2)];
plot([t1 t2],GFP1,'-g','linewidth',4)
plot(t00,GFP01,'--g','linewidth',4)
grid on;
box on;
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',16,'fontname','Times');
annotation('textbox',...
    'String',{['r=',num2str(r(i))]},...
    'fontname','times new roman',...
    'fontsize',16,'fontname','Times',...
    'LineStyle','none',...
    'FitBoxToText','off');
B(i)=c(end,1);
FTA=find(diff(c(:,1))>=0.00001,1,'last');
if ~isempty(FTA)
    RTA(i) = t00(FTA(1));
else
    RTA(i) = 72;
end
end
grid on;
box on;
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
% ylim([0 5])
set(gca,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'GFP strain -50%'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');

figure
hold on
for i=1:length(r)   
[t,c]=ode45(@LARcontrolforR,t00,cinitial,[],r(1,i));
RFP01 = c(:,3);
[t,c]=ode45(@LARcontrolforR,t1,cinitial,[],r(1,i));
cinitial2 = c(end,:);
cinitial2(3) = cinitial2(3).*(1-0.5);
[t,c2]=ode45(@LARcontrolforR,t2,cinitial2,[],r(1,i));
RFP1 = [c(:,3);c2(:,3)];
plot([t1 t2],RFP1,'-r','linewidth',4)
plot(t00,RFP01,'--r','linewidth',4)
grid on;
box on;
xlim([0 72])
set(gca,'xtick',0:24:72,'linewidth',1,'fontsize',16,'fontname','Times');
annotation('textbox',...
    'String',{['r=',num2str(r(i))]},...
    'fontname','times new roman',...
    'fontsize',16,'fontname','Times',...
    'LineStyle','none',...
    'FitBoxToText','off');
B(i)=c(end,1);
FTA=find(diff(c(:,1))>=0.00001,1,'last');
if ~isempty(FTA)
    RTA(i) = t00(FTA(1));
else
    RTA(i) = 72;
end
end
grid on;
box on;
xlabel('Time(Hours)')
ylabel('CFU (10^8)')
% ylim([0 5])
set(gca,'linewidth',1,'fontsize',20,'fontname','Times');
h1 = legend({'RFP strain -50%'},'fontsize',20,'Location','NorthEast');
set(h1,'Box','off');
toc